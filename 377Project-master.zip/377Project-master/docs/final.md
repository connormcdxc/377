Pickup PG: Connor McDonald, Matt Clewley, Robert Moran, Awais, Andrew Loredo

Heroku Link: 

This rest of the document is a brief description of your final presentation.

We created Pickup PG as a way to connect residents of Prince George's County to clean-up efforts around the community. As a group, we saw an opportunity to optimize the current Prince George's County trash collection volunteer system, with an all-in-one site that provides users with both opportunities to easily view current and future clean-ups as well as connect with community clean-up sponsors. 
Identified stakeholders/target browsers. For our project we chose to use a dataset () located on the Prince George's County database website, which contains many datasets pertaning to all aspects of local government and comminity activity.

In order to solve the problems we as a group saw with the pre-existing structure, 
Chosen strategies and solutions for the problem
Technical system decision rationale
How/if your final system helps to address the problem
Challenges faced and impact on final design

While we find Pickup PG to be a success, we feel that we can expand the versatility of Pickup PG to other cities of the state of Maryland and across the country. As long as there is data that supports the upkeeping of previous and future clean-up events in a town or city, our website will be able to serve as a platform for community clean-up efforts. 
